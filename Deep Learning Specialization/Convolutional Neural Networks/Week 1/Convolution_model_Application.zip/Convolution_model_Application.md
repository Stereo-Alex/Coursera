# Convolutional Neural Networks: Application

Welcome to Course 4's second assignment! In this notebook, you will:

- Create a mood classifer using the TF Keras Sequential API
- Build a ConvNet to identify sign language digits using the TF Keras Functional API

**After this assignment you will be able to:**

- Build and train a ConvNet in TensorFlow for a __binary__ classification problem
- Build and train a ConvNet in TensorFlow for a __multiclass__ classification problem
- Explain different use cases for the Sequential and Functional APIs

To complete this assignment, you should already be familiar with TensorFlow. If you are not, please refer back to the **TensorFlow Tutorial** of the third week of Course 2 ("**Improving deep neural networks**").

## Table of Content

- [1 - Packages](#1)
    - [1.1 - Load the Data and Split the Data into Train/Test Sets](#1-1)
- [2 - Layers in TF Keras](#2)
- [3 - The Sequential API](#3)
    - [3.1 - Create the Sequential Model](#3-1)
        - [Exercise 1 - happyModel](#ex-1)
    - [3.2 - Train and Evaluate the Model](#3-2)
- [4 - The Functional API](#4)
    - [4.1 - Load the SIGNS Dataset](#4-1)
    - [4.2 - Split the Data into Train/Test Sets](#4-2)
    - [4.3 - Forward Propagation](#4-3)
        - [Exercise 2 - convolutional_model](#ex-2)
    - [4.4 - Train the Model](#4-4)
- [5 - History Object](#5)
- [6 - Bibliography](#6)

<a name='1'></a>
## 1 - Packages

As usual, begin by loading in the packages.


```python
import math
import numpy as np
import h5py
import matplotlib.pyplot as plt
from matplotlib.pyplot import imread
import scipy
from PIL import Image
#from scipy import ndimage #contains functions for multidimensional image processing
import tensorflow as tf
import tensorflow.keras.layers as tfl
from tensorflow.python.framework import ops
from cnn_utils import *
from test_utils import summary, comparator

%matplotlib inline
np.random.seed(1)
```

<a name='1-1'></a>
### 1.1 - Load the Data and Split the Data into Train/Test Sets

You'll be using the Happy House dataset for this part of the assignment, which contains images of peoples' faces. Your task will be to build a ConvNet that determines whether the people in the images are smiling or not -- because they only get to enter the house if they're smiling!  


```python
X_train_orig, Y_train_orig, X_test_orig, Y_test_orig, classes = load_happy_dataset()

# Normalize image vectors
X_train = X_train_orig/255.
X_test = X_test_orig/255.

# Reshape
Y_train = Y_train_orig.T
Y_test = Y_test_orig.T

print ("number of training examples = " + str(X_train.shape[0]))
print ("number of test examples = " + str(X_test.shape[0]))
print ("X_train shape: " + str(X_train.shape))
print ("Y_train shape: " + str(Y_train.shape))
print ("X_test shape: " + str(X_test.shape))
print ("Y_test shape: " + str(Y_test.shape))
```

    number of training examples = 600
    number of test examples = 150
    X_train shape: (600, 64, 64, 3)
    Y_train shape: (600, 1)
    X_test shape: (150, 64, 64, 3)
    Y_test shape: (150, 1)


You can display the images contained in the dataset. Images are **64x64** pixels in RGB format (3 channels).


```python
index = 124
plt.imshow(X_train_orig[index]) #display sample training image
plt.show()
```


![png](output_7_0.png)


<a name='2'></a>
## 2 - Layers in TF Keras 

In the previous assignment, you created layers manually in numpy. In TF Keras, you don't have to write code directly to create layers. Rather, TF Keras has pre-defined layers you can use. 

When you create a layer in TF Keras, you are creating a function that takes some input and transforms it into an output you can reuse later. Nice and easy! 

<a name='3'></a>
## 3 - The Sequential API

In the previous assignment, you built helper functions using `numpy` to understand the mechanics behind convolutional neural networks. Most practical applications of deep learning today are built using programming frameworks, which have many built-in functions you can simply call. Keras is a high-level abstraction built on top of TensorFlow, which allows for even more simplified and optimized model creation and training. 

For the first part of this assignment, you'll create a model using TF Keras' Sequential API, which allows you to build layer by layer, and is ideal for building models where each layer has **exactly one** input tensor and **one** output tensor. 

As you'll see, using the Sequential API is simple and straightforward, but is only appropriate for simpler, more straightforward tasks. Later in this notebook you'll spend some time building with a more flexible, powerful alternative: the Functional API. 
 

<a name='3-1'></a>
### 3.1 - Create the Sequential Model

As mentioned earlier, the TensorFlow Keras Sequential API can be used to build simple models with layer operations that proceed in a sequential order. 

You can also add layers incrementally to a Sequential model with the `.add()` method, or remove them using the `.pop()` method, much like you would in a regular Python list.

Actually, you can think of a Sequential model as behaving like a list of layers. Like Python lists, Sequential layers are ordered, and the order in which they are specified matters.  If your model is non-linear or contains layers with multiple inputs or outputs, a Sequential model wouldn't be the right choice!

For any layer construction in Keras, you'll need to specify the input shape in advance. This is because in Keras, the shape of the weights is based on the shape of the inputs. The weights are only created when the model first sees some input data. Sequential models can be created by passing a list of layers to the Sequential constructor, like you will do in the next assignment.

<a name='ex-1'></a>
### Exercise 1 - happyModel

Implement the `happyModel` function below to build the following model: `ZEROPAD2D -> CONV2D -> BATCHNORM -> RELU -> MAXPOOL -> FLATTEN -> DENSE`. Take help from [tf.keras.layers](https://www.tensorflow.org/api_docs/python/tf/keras/layers) 

Also, plug in the following parameters for all the steps:

 - [ZeroPadding2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ZeroPadding2D): padding 3, input shape 64 x 64 x 3
 - [Conv2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D): Use 32 7x7 filters, stride 1
 - [BatchNormalization](https://www.tensorflow.org/api_docs/python/tf/keras/layers/BatchNormalization): for axis 3
 - [ReLU](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ReLU)
 - [MaxPool2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/MaxPool2D): Using default parameters
 - [Flatten](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Flatten) the previous output.
 - Fully-connected ([Dense](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dense)) layer: Apply a fully connected layer with 1 neuron and a sigmoid activation. 
 
 
 **Hint:**
 
 Use **tfl** as shorten for **tensorflow.keras.layers**


```python
# GRADED FUNCTION: happyModel

def happyModel():
    """
    Implements the forward propagation for the binary classification model:
    ZEROPAD2D -> CONV2D -> BATCHNORM -> RELU -> MAXPOOL -> FLATTEN -> DENSE
    
    Note that for simplicity and grading purposes, you'll hard-code all the values
    such as the stride and kernel (filter) sizes. 
    Normally, functions should take these values as function parameters.
    
    Arguments:
    None

    Returns:
    model -- TF Keras model (object containing the information for the entire training process) 
    """
    
    model = tf.keras.Sequential([
            ## ZeroPadding2D with padding 3, input shape of 64 x 64 x 3
            tf.keras.layers.ZeroPadding2D(padding =(3),input_shape=(64, 64, 3), data_format="channels_last"),
            ## Conv2D with 32 7x7 filters and stride of 1
            tf.keras.layers.Conv2D(32, (7,7), strides=1),
            ## BatchNormalization for axis 3
            tf.keras.layers.BatchNormalization(axis = 3),
            ## ReLU
            tf.keras.layers.ReLU(),
            ## Max Pooling 2D with default parameters
            tf.keras.layers.MaxPool2D(),
            ## Flatten layer
            tf.keras.layers.Flatten(),
            ## Dense layer with 1 unit for output & 'sigmoid' activation
            tf.keras.layers.Dense(1, activation='sigmoid')
            # YOUR CODE STARTS HERE
            
            
            # YOUR CODE ENDS HERE
        ])
    
    return model

```


```python
happy_model = happyModel()
# Print a summary for each layer
for layer in summary(happy_model):
    print(layer)
    
output = [['ZeroPadding2D', (None, 70, 70, 3), 0, ((3, 3), (3, 3))],
            ['Conv2D', (None, 64, 64, 32), 4736, 'valid', 'linear', 'GlorotUniform'],
            ['BatchNormalization', (None, 64, 64, 32), 128],
            ['ReLU', (None, 64, 64, 32), 0],
            ['MaxPooling2D', (None, 32, 32, 32), 0, (2, 2), (2, 2), 'valid'],
            ['Flatten', (None, 32768), 0],
            ['Dense', (None, 1), 32769, 'sigmoid']]
    
comparator(summary(happy_model), output)
```

    ['ZeroPadding2D', (None, 70, 70, 3), 0, ((3, 3), (3, 3))]
    ['Conv2D', (None, 64, 64, 32), 4736, 'valid', 'linear', 'GlorotUniform']
    ['BatchNormalization', (None, 64, 64, 32), 128]
    ['ReLU', (None, 64, 64, 32), 0]
    ['MaxPooling2D', (None, 32, 32, 32), 0, (2, 2), (2, 2), 'valid']
    ['Flatten', (None, 32768), 0]
    ['Dense', (None, 1), 32769, 'sigmoid']
    [32mAll tests passed![0m


Now that your model is created, you can compile it for training with an optimizer and loss of your choice. When the string `accuracy` is specified as a metric, the type of accuracy used will be automatically converted based on the loss function used. This is one of the many optimizations built into TensorFlow that make your life easier! If you'd like to read more on how the compiler operates, check the docs [here](https://www.tensorflow.org/api_docs/python/tf/keras/Model#compile).


```python
happy_model.compile(optimizer='adam',
                   loss='binary_crossentropy',
                   metrics=['accuracy'])
```

It's time to check your model's parameters with the `.summary()` method. This will display the types of layers you have, the shape of the outputs, and how many parameters are in each layer. 


```python
happy_model.summary()
```

    Model: "sequential"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    zero_padding2d_10 (ZeroPaddi (None, 70, 70, 3)         0         
    _________________________________________________________________
    conv2d (Conv2D)              (None, 64, 64, 32)        4736      
    _________________________________________________________________
    batch_normalization (BatchNo (None, 64, 64, 32)        128       
    _________________________________________________________________
    re_lu (ReLU)                 (None, 64, 64, 32)        0         
    _________________________________________________________________
    max_pooling2d (MaxPooling2D) (None, 32, 32, 32)        0         
    _________________________________________________________________
    flatten (Flatten)            (None, 32768)             0         
    _________________________________________________________________
    dense (Dense)                (None, 1)                 32769     
    =================================================================
    Total params: 37,633
    Trainable params: 37,569
    Non-trainable params: 64
    _________________________________________________________________


<a name='3-2'></a>
### 3.2 - Train and Evaluate the Model

After creating the model, compiling it with your choice of optimizer and loss function, and doing a sanity check on its contents, you are now ready to build! 

Simply call `.fit()` to train. That's it! No need for mini-batching, saving, or complex backpropagation computations. That's all been done for you, as you're using a TensorFlow dataset with the batches specified already. You do have the option to specify epoch number or minibatch size if you like (for example, in the case of an un-batched dataset).


```python
happy_model.fit(X_train, Y_train, epochs=10, batch_size=16)
```

    Epoch 1/10
    38/38 [==============================] - 4s 100ms/step - loss: 1.4643 - accuracy: 0.6917
    Epoch 2/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.2561 - accuracy: 0.9017
    Epoch 3/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.1843 - accuracy: 0.9183
    Epoch 4/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.1025 - accuracy: 0.9617
    Epoch 5/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.1068 - accuracy: 0.9567
    Epoch 6/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.1152 - accuracy: 0.9633
    Epoch 7/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.0888 - accuracy: 0.9700
    Epoch 8/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.1432 - accuracy: 0.9383
    Epoch 9/10
    38/38 [==============================] - 4s 97ms/step - loss: 0.1008 - accuracy: 0.9717
    Epoch 10/10
    38/38 [==============================] - 4s 95ms/step - loss: 0.0745 - accuracy: 0.9767





    <tensorflow.python.keras.callbacks.History at 0x7f38033309d0>



After that completes, just use `.evaluate()` to evaluate against your test set. This function will print the value of the loss function and the performance metrics specified during the compilation of the model. In this case, the `binary_crossentropy` and the `accuracy` respectively.


```python
happy_model.evaluate(X_test, Y_test)
```

    5/5 [==============================] - 0s 40ms/step - loss: 0.1230 - accuracy: 0.9533





    [0.1230325698852539, 0.95333331823349]



Easy, right? But what if you need to build a model with shared layers, branches, or multiple inputs and outputs? This is where Sequential, with its beautifully simple yet limited functionality, won't be able to help you. 

Next up: Enter the Functional API, your slightly more complex, highly flexible friend.  

<a name='4'></a>
## 4 - The Functional API

Welcome to the second half of the assignment, where you'll use Keras' flexible [Functional API](https://www.tensorflow.org/guide/keras/functional) to build a ConvNet that can differentiate between 6 sign language digits. 

The Functional API can handle models with non-linear topology, shared layers, as well as layers with multiple inputs or outputs. Imagine that, where the Sequential API requires the model to move in a linear fashion through its layers, the Functional API allows much more flexibility. Where Sequential is a straight line, a Functional model is a graph, where the nodes of the layers can connect in many more ways than one. 

In the visual example below, the one possible direction of the movement Sequential model is shown in contrast to a skip connection, which is just one of the many ways a Functional model can be constructed. A skip connection, as you might have guessed, skips some layer in the network and feeds the output to a later layer in the network. Don't worry, you'll be spending more time with skip connections very soon! 

<img src="images/seq_vs_func.png" style="width:350px;height:200px;">

<a name='4-1'></a>
### 4.1 - Load the SIGNS Dataset

As a reminder, the SIGNS dataset is a collection of 6 signs representing numbers from 0 to 5.


```python
# Loading the data (signs)
X_train_orig, Y_train_orig, X_test_orig, Y_test_orig, classes = load_signs_dataset()
```

<img src="images/SIGNS.png" style="width:800px;height:300px;">

The next cell will show you an example of a labelled image in the dataset. Feel free to change the value of `index` below and re-run to see different examples. 


```python
# Example of an image from the dataset
index = 9
plt.imshow(X_train_orig[index])
print ("y = " + str(np.squeeze(Y_train_orig[:, index])))
```

    y = 4



![png](output_28_1.png)


<a name='4-2'></a>
### 4.2 - Split the Data into Train/Test Sets

In Course 2, you built a fully-connected network for this dataset. But since this is an image dataset, it is more natural to apply a ConvNet to it.

To get started, let's examine the shapes of your data. 


```python
X_train = X_train_orig/255.
X_test = X_test_orig/255.
Y_train = convert_to_one_hot(Y_train_orig, 6).T
Y_test = convert_to_one_hot(Y_test_orig, 6).T
print ("number of training examples = " + str(X_train.shape[0]))
print ("number of test examples = " + str(X_test.shape[0]))
print ("X_train shape: " + str(X_train.shape))
print ("Y_train shape: " + str(Y_train.shape))
print ("X_test shape: " + str(X_test.shape))
print ("Y_test shape: " + str(Y_test.shape))
```

    number of training examples = 1080
    number of test examples = 120
    X_train shape: (1080, 64, 64, 3)
    Y_train shape: (1080, 6)
    X_test shape: (120, 64, 64, 3)
    Y_test shape: (120, 6)


<a name='4-3'></a>
### 4.3 - Forward Propagation

In TensorFlow, there are built-in functions that implement the convolution steps for you. By now, you should be familiar with how TensorFlow builds computational graphs. In the [Functional API](https://www.tensorflow.org/guide/keras/functional), you create a graph of layers. This is what allows such great flexibility.

However, the following model could also be defined using the Sequential API since the information flow is on a single line. But don't deviate. What we want you to learn is to use the functional API.

Begin building your graph of layers by creating an input node that functions as a callable object:

- **input_img = tf.keras.Input(shape=input_shape):** 

Then, create a new node in the graph of layers by calling a layer on the `input_img` object: 

- **tf.keras.layers.Conv2D(filters= ... , kernel_size= ... , padding='same')(input_img):** Read the full documentation on [Conv2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D).

- **tf.keras.layers.MaxPool2D(pool_size=(f, f), strides=(s, s), padding='same'):** `MaxPool2D()` downsamples your input using a window of size (f, f) and strides of size (s, s) to carry out max pooling over each window.  For max pooling, you usually operate on a single example at a time and a single channel at a time. Read the full documentation on [MaxPool2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/MaxPool2D).

- **tf.keras.layers.ReLU():** computes the elementwise ReLU of Z (which can be any shape). You can read the full documentation on [ReLU](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ReLU).

- **tf.keras.layers.Flatten()**: given a tensor "P", this function takes each training (or test) example in the batch and flattens it into a 1D vector.  

    * If a tensor P has the shape (batch_size,h,w,c), it returns a flattened tensor with shape (batch_size, k), where $k=h \times w \times c$.  "k" equals the product of all the dimension sizes other than the first dimension.
    
    * For example, given a tensor with dimensions [100, 2, 3, 4], it flattens the tensor to be of shape [100, 24], where 24 = 2 * 3 * 4.  You can read the full documentation on [Flatten](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Flatten).

- **tf.keras.layers.Dense(units= ... , activation='softmax')(F):** given the flattened input F, it returns the output computed using a fully connected layer. You can read the full documentation on [Dense](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dense).

In the last function above (`tf.keras.layers.Dense()`), the fully connected layer automatically initializes weights in the graph and keeps on training them as you train the model. Hence, you did not need to initialize those weights when initializing the parameters.

Lastly, before creating the model, you'll need to define the output using the last of the function's compositions (in this example, a Dense layer): 

- **outputs = tf.keras.layers.Dense(units=6, activation='softmax')(F)**


#### Window, kernel, filter, pool

The words "kernel" and "filter" are used to refer to the same thing. The word "filter" accounts for the amount of "kernels" that will be used in a single convolution layer. "Pool" is the name of the operation that takes the max or average value of the kernels. 

This is why the parameter `pool_size` refers to `kernel_size`, and you use `(f,f)` to refer to the filter size. 

Pool size and kernel size refer to the same thing in different objects - They refer to the shape of the window where the operation takes place. 

<a name='ex-2'></a>
### Exercise 2 - convolutional_model

Implement the `convolutional_model` function below to build the following model: `CONV2D -> RELU -> MAXPOOL -> CONV2D -> RELU -> MAXPOOL -> FLATTEN -> DENSE`. Use the functions above! 

Also, plug in the following parameters for all the steps:

 - [Conv2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Conv2D): Use 8 4 by 4 filters, stride 1, padding is "SAME"
 - [ReLU](https://www.tensorflow.org/api_docs/python/tf/keras/layers/ReLU)
 - [MaxPool2D](https://www.tensorflow.org/api_docs/python/tf/keras/layers/MaxPool2D): Use an 8 by 8 filter size and an 8 by 8 stride, padding is "SAME"
 - **Conv2D**: Use 16 2 by 2 filters, stride 1, padding is "SAME"
 - **ReLU**
 - **MaxPool2D**: Use a 4 by 4 filter size and a 4 by 4 stride, padding is "SAME"
 - [Flatten](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Flatten) the previous output.
 - Fully-connected ([Dense](https://www.tensorflow.org/api_docs/python/tf/keras/layers/Dense)) layer: Apply a fully connected layer with 6 neurons and a softmax activation. 


```python
# GRADED FUNCTION: convolutional_model

def convolutional_model(input_shape):
    """
    Implements the forward propagation for the model:
    CONV2D -> RELU -> MAXPOOL -> CONV2D -> RELU -> MAXPOOL -> FLATTEN -> DENSE
    
    Note that for simplicity and grading purposes, you'll hard-code some values
    such as the stride and kernel (filter) sizes. 
    Normally, functions should take these values as function parameters.
    
    Arguments:
    input_img -- input dataset, of shape (input_shape)

    Returns:
    model -- TF Keras model (object containing the information for the entire training process) 
    """

    input_img = tf.keras.Input(shape=input_shape)
    
    ## CONV2D: 8 filters 4x4, stride of 1, padding 'SAME'
    Z1 = tf.keras.layers.Conv2D(8, (4,4), strides=(1), padding='SAME')(input_img)
    ## RELU
    A1 = tf.keras.layers.ReLU()(Z1)
    ## MAXPOOL: window 8x8, stride 8, padding 'SAME'
    P1 = tf.keras.layers.MaxPool2D(pool_size=(8 ,8), strides=(8,8), padding='SAME')(A1)
    ## CONV2D: 16 filters 2x2, stride 1, padding 'SAME'
    Z2 = tf.keras.layers.Conv2D(16, (2,2), strides=(1), padding='SAME')(P1)
    ## RELU
    A2 = tf.keras.layers.ReLU()(Z2)
    ## MAXPOOL: window 4x4, stride 4, padding 'SAME'
    P2 = tf.keras.layers.MaxPool2D(pool_size=(4, 4), strides=(4,4), padding='SAME')(A2)

    ## FLATTEN
    F = tf.keras.layers.Flatten()(P2)
    ## Dense layer
    ## 6 neurons in output layer. Hint: one of the arguments should be "activation='softmax'" 
    outputs = tf.keras.layers.Dense(6, activation='softmax')(F)
    # YOUR CODE STARTS HERE
    
    
    # YOUR CODE ENDS HERE
    model = tf.keras.Model(inputs=input_img, outputs=outputs)
    return model
```


```python
conv_model = convolutional_model((64, 64, 3))
conv_model.compile(optimizer='adam',
                  loss='categorical_crossentropy',
                  metrics=['accuracy'])
conv_model.summary()
    
output = [['InputLayer', [(None, 64, 64, 3)], 0],
        ['Conv2D', (None, 64, 64, 8), 392, 'same', 'linear', 'GlorotUniform'],
        ['ReLU', (None, 64, 64, 8), 0],
        ['MaxPooling2D', (None, 8, 8, 8), 0, (8, 8), (8, 8), 'same'],
        ['Conv2D', (None, 8, 8, 16), 528, 'same', 'linear', 'GlorotUniform'],
        ['ReLU', (None, 8, 8, 16), 0],
        ['MaxPooling2D', (None, 2, 2, 16), 0, (4, 4), (4, 4), 'same'],
        ['Flatten', (None, 64), 0],
        ['Dense', (None, 6), 390, 'softmax']]
    
comparator(summary(conv_model), output)
```

    Model: "functional_3"
    _________________________________________________________________
    Layer (type)                 Output Shape              Param #   
    =================================================================
    input_8 (InputLayer)         [(None, 64, 64, 3)]       0         
    _________________________________________________________________
    conv2d_13 (Conv2D)           (None, 64, 64, 8)         392       
    _________________________________________________________________
    re_lu_13 (ReLU)              (None, 64, 64, 8)         0         
    _________________________________________________________________
    max_pooling2d_11 (MaxPooling (None, 8, 8, 8)           0         
    _________________________________________________________________
    conv2d_14 (Conv2D)           (None, 8, 8, 16)          528       
    _________________________________________________________________
    re_lu_14 (ReLU)              (None, 8, 8, 16)          0         
    _________________________________________________________________
    max_pooling2d_12 (MaxPooling (None, 2, 2, 16)          0         
    _________________________________________________________________
    flatten_6 (Flatten)          (None, 64)                0         
    _________________________________________________________________
    dense_6 (Dense)              (None, 6)                 390       
    =================================================================
    Total params: 1,310
    Trainable params: 1,310
    Non-trainable params: 0
    _________________________________________________________________
    [32mAll tests passed![0m


Both the Sequential and Functional APIs return a TF Keras model object. The only difference is how inputs are handled inside the object model! 

<a name='4-4'></a>
### 4.4 - Train the Model


```python
train_dataset = tf.data.Dataset.from_tensor_slices((X_train, Y_train)).batch(64)
test_dataset = tf.data.Dataset.from_tensor_slices((X_test, Y_test)).batch(64)
history = conv_model.fit(train_dataset, epochs=100, validation_data=test_dataset)
```

    Epoch 1/100
    17/17 [==============================] - 2s 113ms/step - loss: 1.8128 - accuracy: 0.1944 - val_loss: 1.7898 - val_accuracy: 0.1667
    Epoch 2/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.7838 - accuracy: 0.1741 - val_loss: 1.7820 - val_accuracy: 0.2083
    Epoch 3/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7771 - accuracy: 0.2333 - val_loss: 1.7767 - val_accuracy: 0.2583
    Epoch 4/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7707 - accuracy: 0.2981 - val_loss: 1.7710 - val_accuracy: 0.2833
    Epoch 5/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7643 - accuracy: 0.3185 - val_loss: 1.7649 - val_accuracy: 0.3000
    Epoch 6/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.7576 - accuracy: 0.3620 - val_loss: 1.7581 - val_accuracy: 0.3583
    Epoch 7/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.7494 - accuracy: 0.3731 - val_loss: 1.7497 - val_accuracy: 0.3667
    Epoch 8/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.7404 - accuracy: 0.4130 - val_loss: 1.7414 - val_accuracy: 0.4000
    Epoch 9/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.7299 - accuracy: 0.4278 - val_loss: 1.7310 - val_accuracy: 0.4167
    Epoch 10/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7176 - accuracy: 0.4454 - val_loss: 1.7189 - val_accuracy: 0.4417
    Epoch 11/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.7033 - accuracy: 0.4704 - val_loss: 1.7046 - val_accuracy: 0.4500
    Epoch 12/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.6852 - accuracy: 0.4843 - val_loss: 1.6855 - val_accuracy: 0.4750
    Epoch 13/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.6627 - accuracy: 0.4944 - val_loss: 1.6629 - val_accuracy: 0.5000
    Epoch 14/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.6353 - accuracy: 0.5019 - val_loss: 1.6365 - val_accuracy: 0.4917
    Epoch 15/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.6021 - accuracy: 0.4972 - val_loss: 1.6014 - val_accuracy: 0.4750
    Epoch 16/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.5629 - accuracy: 0.4981 - val_loss: 1.5719 - val_accuracy: 0.4583
    Epoch 17/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.5177 - accuracy: 0.5213 - val_loss: 1.5241 - val_accuracy: 0.4583
    Epoch 18/100
    17/17 [==============================] - 2s 102ms/step - loss: 1.4715 - accuracy: 0.5389 - val_loss: 1.4794 - val_accuracy: 0.4833
    Epoch 19/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.4246 - accuracy: 0.5481 - val_loss: 1.4335 - val_accuracy: 0.5000
    Epoch 20/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.3775 - accuracy: 0.5639 - val_loss: 1.3876 - val_accuracy: 0.4750
    Epoch 21/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.3304 - accuracy: 0.5796 - val_loss: 1.3423 - val_accuracy: 0.5333
    Epoch 22/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.2828 - accuracy: 0.6093 - val_loss: 1.2923 - val_accuracy: 0.5667
    Epoch 23/100
    17/17 [==============================] - 2s 107ms/step - loss: 1.2405 - accuracy: 0.6204 - val_loss: 1.2542 - val_accuracy: 0.6083
    Epoch 24/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.1994 - accuracy: 0.6426 - val_loss: 1.2124 - val_accuracy: 0.6250
    Epoch 25/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.1596 - accuracy: 0.6435 - val_loss: 1.1732 - val_accuracy: 0.6417
    Epoch 26/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.1225 - accuracy: 0.6620 - val_loss: 1.1332 - val_accuracy: 0.6667
    Epoch 27/100
    17/17 [==============================] - 2s 111ms/step - loss: 1.0871 - accuracy: 0.6593 - val_loss: 1.0965 - val_accuracy: 0.6750
    Epoch 28/100
    17/17 [==============================] - 2s 106ms/step - loss: 1.0542 - accuracy: 0.6843 - val_loss: 1.0609 - val_accuracy: 0.6750
    Epoch 29/100
    17/17 [==============================] - 2s 101ms/step - loss: 1.0239 - accuracy: 0.6833 - val_loss: 1.0302 - val_accuracy: 0.6917
    Epoch 30/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.9983 - accuracy: 0.6889 - val_loss: 1.0004 - val_accuracy: 0.6917
    Epoch 31/100
    17/17 [==============================] - 2s 102ms/step - loss: 0.9712 - accuracy: 0.6944 - val_loss: 0.9707 - val_accuracy: 0.6917
    Epoch 32/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.9482 - accuracy: 0.7009 - val_loss: 0.9458 - val_accuracy: 0.7000
    Epoch 33/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.9249 - accuracy: 0.7046 - val_loss: 0.9222 - val_accuracy: 0.7083
    Epoch 34/100
    17/17 [==============================] - 2s 101ms/step - loss: 0.9037 - accuracy: 0.7074 - val_loss: 0.8994 - val_accuracy: 0.7250
    Epoch 35/100
    17/17 [==============================] - 2s 102ms/step - loss: 0.8856 - accuracy: 0.7111 - val_loss: 0.8785 - val_accuracy: 0.7417
    Epoch 36/100
    17/17 [==============================] - 2s 105ms/step - loss: 0.8670 - accuracy: 0.7130 - val_loss: 0.8585 - val_accuracy: 0.7583
    Epoch 37/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.8512 - accuracy: 0.7157 - val_loss: 0.8413 - val_accuracy: 0.7500
    Epoch 38/100
    17/17 [==============================] - 2s 105ms/step - loss: 0.8338 - accuracy: 0.7259 - val_loss: 0.8247 - val_accuracy: 0.7667
    Epoch 39/100
    17/17 [==============================] - ETA: 0s - loss: 0.8198 - accuracy: 0.72 - 2s 106ms/step - loss: 0.8198 - accuracy: 0.7241 - val_loss: 0.8094 - val_accuracy: 0.7667
    Epoch 40/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.8048 - accuracy: 0.7333 - val_loss: 0.7953 - val_accuracy: 0.7667
    Epoch 41/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.7931 - accuracy: 0.7315 - val_loss: 0.7811 - val_accuracy: 0.7750
    Epoch 42/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.7799 - accuracy: 0.7352 - val_loss: 0.7697 - val_accuracy: 0.7750
    Epoch 43/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7677 - accuracy: 0.7407 - val_loss: 0.7575 - val_accuracy: 0.7750
    Epoch 44/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7578 - accuracy: 0.7435 - val_loss: 0.7461 - val_accuracy: 0.7917
    Epoch 45/100
    17/17 [==============================] - 2s 101ms/step - loss: 0.7468 - accuracy: 0.7509 - val_loss: 0.7368 - val_accuracy: 0.7750
    Epoch 46/100
    17/17 [==============================] - 2s 101ms/step - loss: 0.7351 - accuracy: 0.7537 - val_loss: 0.7257 - val_accuracy: 0.7833
    Epoch 47/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.7264 - accuracy: 0.7546 - val_loss: 0.7166 - val_accuracy: 0.7750
    Epoch 48/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7171 - accuracy: 0.7593 - val_loss: 0.7077 - val_accuracy: 0.7833
    Epoch 49/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.7064 - accuracy: 0.7602 - val_loss: 0.6985 - val_accuracy: 0.7917
    Epoch 50/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6982 - accuracy: 0.7639 - val_loss: 0.6914 - val_accuracy: 0.7917
    Epoch 51/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6897 - accuracy: 0.7667 - val_loss: 0.6831 - val_accuracy: 0.7917
    Epoch 52/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6816 - accuracy: 0.7630 - val_loss: 0.6757 - val_accuracy: 0.8000
    Epoch 53/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6733 - accuracy: 0.7685 - val_loss: 0.6692 - val_accuracy: 0.8083
    Epoch 54/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6669 - accuracy: 0.7750 - val_loss: 0.6620 - val_accuracy: 0.8083
    Epoch 55/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6578 - accuracy: 0.7741 - val_loss: 0.6546 - val_accuracy: 0.8083
    Epoch 56/100
    17/17 [==============================] - 2s 105ms/step - loss: 0.6498 - accuracy: 0.7815 - val_loss: 0.6485 - val_accuracy: 0.8083
    Epoch 57/100
    17/17 [==============================] - 2s 102ms/step - loss: 0.6423 - accuracy: 0.7806 - val_loss: 0.6424 - val_accuracy: 0.8083
    Epoch 58/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6366 - accuracy: 0.7815 - val_loss: 0.6385 - val_accuracy: 0.8000
    Epoch 59/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6289 - accuracy: 0.7824 - val_loss: 0.6308 - val_accuracy: 0.8167
    Epoch 60/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6233 - accuracy: 0.7824 - val_loss: 0.6272 - val_accuracy: 0.8167
    Epoch 61/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6162 - accuracy: 0.7852 - val_loss: 0.6232 - val_accuracy: 0.8167
    Epoch 62/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6100 - accuracy: 0.7861 - val_loss: 0.6183 - val_accuracy: 0.8083
    Epoch 63/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.6017 - accuracy: 0.7870 - val_loss: 0.6121 - val_accuracy: 0.8000
    Epoch 64/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5963 - accuracy: 0.7898 - val_loss: 0.6113 - val_accuracy: 0.8083
    Epoch 65/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.5886 - accuracy: 0.7935 - val_loss: 0.6022 - val_accuracy: 0.8083
    Epoch 66/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5843 - accuracy: 0.7954 - val_loss: 0.6025 - val_accuracy: 0.8000
    Epoch 67/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.5775 - accuracy: 0.7954 - val_loss: 0.5943 - val_accuracy: 0.8000
    Epoch 68/100
    17/17 [==============================] - 2s 101ms/step - loss: 0.5729 - accuracy: 0.7981 - val_loss: 0.5928 - val_accuracy: 0.8000
    Epoch 69/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5673 - accuracy: 0.8009 - val_loss: 0.5859 - val_accuracy: 0.8000
    Epoch 70/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5614 - accuracy: 0.8056 - val_loss: 0.5838 - val_accuracy: 0.8000
    Epoch 71/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5561 - accuracy: 0.8083 - val_loss: 0.5798 - val_accuracy: 0.8000
    Epoch 72/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5503 - accuracy: 0.8111 - val_loss: 0.5763 - val_accuracy: 0.8083
    Epoch 73/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5456 - accuracy: 0.8148 - val_loss: 0.5724 - val_accuracy: 0.8083
    Epoch 74/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5402 - accuracy: 0.8222 - val_loss: 0.5686 - val_accuracy: 0.8083
    Epoch 75/100
    17/17 [==============================] - 2s 112ms/step - loss: 0.5361 - accuracy: 0.8213 - val_loss: 0.5651 - val_accuracy: 0.8167
    Epoch 76/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.5306 - accuracy: 0.8231 - val_loss: 0.5606 - val_accuracy: 0.8167
    Epoch 77/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5261 - accuracy: 0.8241 - val_loss: 0.5572 - val_accuracy: 0.8167
    Epoch 78/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5210 - accuracy: 0.8250 - val_loss: 0.5559 - val_accuracy: 0.8167
    Epoch 79/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5171 - accuracy: 0.8269 - val_loss: 0.5519 - val_accuracy: 0.8167
    Epoch 80/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.5122 - accuracy: 0.8259 - val_loss: 0.5508 - val_accuracy: 0.8167
    Epoch 81/100
    17/17 [==============================] - 2s 102ms/step - loss: 0.5081 - accuracy: 0.8278 - val_loss: 0.5448 - val_accuracy: 0.8083
    Epoch 82/100
    17/17 [==============================] - 2s 105ms/step - loss: 0.5044 - accuracy: 0.8269 - val_loss: 0.5433 - val_accuracy: 0.8250
    Epoch 83/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4996 - accuracy: 0.8306 - val_loss: 0.5384 - val_accuracy: 0.8167
    Epoch 84/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4956 - accuracy: 0.8315 - val_loss: 0.5326 - val_accuracy: 0.8167
    Epoch 85/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.4910 - accuracy: 0.8306 - val_loss: 0.5317 - val_accuracy: 0.8167
    Epoch 86/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4870 - accuracy: 0.8361 - val_loss: 0.5267 - val_accuracy: 0.8250
    Epoch 87/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4827 - accuracy: 0.8352 - val_loss: 0.5270 - val_accuracy: 0.8333
    Epoch 88/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4794 - accuracy: 0.8380 - val_loss: 0.5224 - val_accuracy: 0.8250
    Epoch 89/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4756 - accuracy: 0.8398 - val_loss: 0.5217 - val_accuracy: 0.8250
    Epoch 90/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4722 - accuracy: 0.8426 - val_loss: 0.5195 - val_accuracy: 0.8333
    Epoch 91/100
    17/17 [==============================] - 2s 107ms/step - loss: 0.4683 - accuracy: 0.8454 - val_loss: 0.5170 - val_accuracy: 0.8333
    Epoch 92/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4649 - accuracy: 0.8454 - val_loss: 0.5145 - val_accuracy: 0.8417
    Epoch 93/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4613 - accuracy: 0.8454 - val_loss: 0.5131 - val_accuracy: 0.8417
    Epoch 94/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4580 - accuracy: 0.8472 - val_loss: 0.5118 - val_accuracy: 0.8417
    Epoch 95/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4544 - accuracy: 0.8463 - val_loss: 0.5073 - val_accuracy: 0.8417
    Epoch 96/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4509 - accuracy: 0.8481 - val_loss: 0.5058 - val_accuracy: 0.8583
    Epoch 97/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4482 - accuracy: 0.8444 - val_loss: 0.5039 - val_accuracy: 0.8667
    Epoch 98/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4448 - accuracy: 0.8472 - val_loss: 0.5041 - val_accuracy: 0.8500
    Epoch 99/100
    17/17 [==============================] - 2s 111ms/step - loss: 0.4415 - accuracy: 0.8509 - val_loss: 0.5011 - val_accuracy: 0.8583
    Epoch 100/100
    17/17 [==============================] - 2s 106ms/step - loss: 0.4388 - accuracy: 0.8472 - val_loss: 0.4974 - val_accuracy: 0.8583


<a name='5'></a>
## 5 - History Object 

The history object is an output of the `.fit()` operation, and provides a record of all the loss and metric values in memory. It's stored as a dictionary that you can retrieve at `history.history`: 


```python
history.history
```




    {'loss': [1.8128154277801514,
      1.7837512493133545,
      1.7771459817886353,
      1.7706884145736694,
      1.7643084526062012,
      1.757596492767334,
      1.7494356632232666,
      1.7403684854507446,
      1.729945182800293,
      1.7175723314285278,
      1.703254222869873,
      1.685206651687622,
      1.662704348564148,
      1.6352936029434204,
      1.6021368503570557,
      1.5628644227981567,
      1.5177279710769653,
      1.4714542627334595,
      1.4245741367340088,
      1.377518653869629,
      1.3303700685501099,
      1.2828396558761597,
      1.2405391931533813,
      1.1994022130966187,
      1.1595754623413086,
      1.1224546432495117,
      1.0870980024337769,
      1.054232120513916,
      1.0239447355270386,
      0.9982798099517822,
      0.9711659550666809,
      0.9481853246688843,
      0.9249085783958435,
      0.9037252068519592,
      0.8855974078178406,
      0.8669662475585938,
      0.851225733757019,
      0.8338252902030945,
      0.8198485970497131,
      0.8048086166381836,
      0.7931108474731445,
      0.7799038887023926,
      0.7677227854728699,
      0.7578032612800598,
      0.7468060255050659,
      0.7350654602050781,
      0.726376473903656,
      0.7170881032943726,
      0.7063724994659424,
      0.6982173919677734,
      0.6897321343421936,
      0.6815717816352844,
      0.6732658743858337,
      0.6668775677680969,
      0.6578233242034912,
      0.649800717830658,
      0.6423190832138062,
      0.6366056799888611,
      0.6288532614707947,
      0.6233128905296326,
      0.6161929368972778,
      0.6100485920906067,
      0.6016944050788879,
      0.5963459014892578,
      0.5886445641517639,
      0.5843217372894287,
      0.5774728655815125,
      0.5728954076766968,
      0.567348301410675,
      0.5613650679588318,
      0.5560703277587891,
      0.5503024458885193,
      0.5455539226531982,
      0.5402478575706482,
      0.5360583066940308,
      0.5305885672569275,
      0.5260615348815918,
      0.5210257768630981,
      0.5170975923538208,
      0.5122224688529968,
      0.508106529712677,
      0.5043787360191345,
      0.4996202290058136,
      0.4955906569957733,
      0.49103790521621704,
      0.487039178609848,
      0.482711523771286,
      0.4794134497642517,
      0.47562816739082336,
      0.4721700847148895,
      0.46830904483795166,
      0.4649301767349243,
      0.4613302946090698,
      0.45802226662635803,
      0.4544065296649933,
      0.4509451389312744,
      0.448184609413147,
      0.4448394179344177,
      0.4414714276790619,
      0.4387669861316681],
     'accuracy': [0.1944444477558136,
      0.17407406866550446,
      0.23333333432674408,
      0.29814815521240234,
      0.3185185194015503,
      0.3620370328426361,
      0.3731481432914734,
      0.41296297311782837,
      0.4277777671813965,
      0.4453703761100769,
      0.4703703820705414,
      0.4842592477798462,
      0.49444442987442017,
      0.5018518567085266,
      0.4972222149372101,
      0.4981481432914734,
      0.5212963223457336,
      0.5388888716697693,
      0.5481481552124023,
      0.5638889074325562,
      0.5796296000480652,
      0.6092592477798462,
      0.6203703880310059,
      0.6425926089286804,
      0.6435185074806213,
      0.6620370149612427,
      0.6592592597007751,
      0.6842592358589172,
      0.6833333373069763,
      0.6888889074325562,
      0.6944444179534912,
      0.7009259462356567,
      0.7046296000480652,
      0.7074074149131775,
      0.7111111283302307,
      0.7129629850387573,
      0.7157407402992249,
      0.7259259223937988,
      0.7240740656852722,
      0.7333333492279053,
      0.7314814925193787,
      0.7351852059364319,
      0.7407407164573669,
      0.7435185313224792,
      0.7509258985519409,
      0.7537037134170532,
      0.7546296119689941,
      0.7592592835426331,
      0.760185182094574,
      0.7638888955116272,
      0.7666666507720947,
      0.7629629373550415,
      0.7685185074806213,
      0.7749999761581421,
      0.7740740776062012,
      0.7814815044403076,
      0.7805555462837219,
      0.7814815044403076,
      0.7824074029922485,
      0.7824074029922485,
      0.7851851582527161,
      0.7861111164093018,
      0.7870370149612427,
      0.789814829826355,
      0.7935185432434082,
      0.7953703999519348,
      0.7953703999519348,
      0.7981481552124023,
      0.8009259104728699,
      0.8055555820465088,
      0.8083333373069763,
      0.8111110925674438,
      0.8148148059844971,
      0.8222222328186035,
      0.8212962746620178,
      0.8231481313705444,
      0.8240740895271301,
      0.824999988079071,
      0.8268518447875977,
      0.8259259462356567,
      0.8277778029441833,
      0.8268518447875977,
      0.8305555582046509,
      0.8314814567565918,
      0.8305555582046509,
      0.8361111283302307,
      0.835185170173645,
      0.8379629850387573,
      0.8398148417472839,
      0.8425925970077515,
      0.845370352268219,
      0.845370352268219,
      0.845370352268219,
      0.8472222089767456,
      0.8462963104248047,
      0.8481481671333313,
      0.8444444537162781,
      0.8472222089767456,
      0.8509259223937988,
      0.8472222089767456],
     'val_loss': [1.7898423671722412,
      1.7820488214492798,
      1.7766971588134766,
      1.7710033655166626,
      1.764912724494934,
      1.7581313848495483,
      1.7496508359909058,
      1.74135422706604,
      1.7310408353805542,
      1.718939185142517,
      1.704583764076233,
      1.6855343580245972,
      1.66291081905365,
      1.6364580392837524,
      1.6014317274093628,
      1.5719233751296997,
      1.5240931510925293,
      1.4794307947158813,
      1.4334754943847656,
      1.3875946998596191,
      1.3422973155975342,
      1.2923121452331543,
      1.2542495727539062,
      1.212427020072937,
      1.1731762886047363,
      1.1332013607025146,
      1.096548080444336,
      1.0609458684921265,
      1.0302377939224243,
      1.0004369020462036,
      0.9707433581352234,
      0.9458000063896179,
      0.9221783876419067,
      0.8994380831718445,
      0.8785317540168762,
      0.8585202693939209,
      0.8413036465644836,
      0.8246843814849854,
      0.8094332218170166,
      0.7952530980110168,
      0.7811037302017212,
      0.7696669101715088,
      0.7575036287307739,
      0.7461443543434143,
      0.7367531061172485,
      0.7257044911384583,
      0.7165860533714294,
      0.707651674747467,
      0.6985082626342773,
      0.691376268863678,
      0.6830605864524841,
      0.6756662726402283,
      0.6692423224449158,
      0.6620076894760132,
      0.6546333432197571,
      0.6485050320625305,
      0.6424443125724792,
      0.6384511590003967,
      0.6308292746543884,
      0.6272171139717102,
      0.6231510043144226,
      0.6182959079742432,
      0.6120744347572327,
      0.6112775206565857,
      0.6022303700447083,
      0.6025269627571106,
      0.5942503809928894,
      0.5927733182907104,
      0.585932195186615,
      0.5837633609771729,
      0.5798291563987732,
      0.5763464570045471,
      0.572374165058136,
      0.5686146020889282,
      0.5651357769966125,
      0.5606256127357483,
      0.5572359561920166,
      0.5558764338493347,
      0.5519246459007263,
      0.5508042573928833,
      0.5447999835014343,
      0.5432989001274109,
      0.5384247899055481,
      0.5326371192932129,
      0.5316838026046753,
      0.5267411470413208,
      0.5270411968231201,
      0.5224334001541138,
      0.5216763615608215,
      0.519497275352478,
      0.5169874429702759,
      0.5145183205604553,
      0.5131112337112427,
      0.5118109583854675,
      0.5072625875473022,
      0.505780041217804,
      0.5038677453994751,
      0.5040922164916992,
      0.5011223554611206,
      0.4974415898323059],
     'val_accuracy': [0.1666666716337204,
      0.2083333283662796,
      0.25833332538604736,
      0.28333333134651184,
      0.30000001192092896,
      0.3583333194255829,
      0.36666667461395264,
      0.4000000059604645,
      0.4166666567325592,
      0.4416666626930237,
      0.44999998807907104,
      0.4749999940395355,
      0.5,
      0.49166667461395264,
      0.4749999940395355,
      0.4583333432674408,
      0.4583333432674408,
      0.4833333194255829,
      0.5,
      0.4749999940395355,
      0.5333333611488342,
      0.5666666626930237,
      0.6083333492279053,
      0.625,
      0.6416666507720947,
      0.6666666865348816,
      0.675000011920929,
      0.675000011920929,
      0.6916666626930237,
      0.6916666626930237,
      0.6916666626930237,
      0.699999988079071,
      0.7083333134651184,
      0.7250000238418579,
      0.7416666746139526,
      0.7583333253860474,
      0.75,
      0.7666666507720947,
      0.7666666507720947,
      0.7666666507720947,
      0.7749999761581421,
      0.7749999761581421,
      0.7749999761581421,
      0.7916666865348816,
      0.7749999761581421,
      0.7833333611488342,
      0.7749999761581421,
      0.7833333611488342,
      0.7916666865348816,
      0.7916666865348816,
      0.7916666865348816,
      0.800000011920929,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.800000011920929,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.8083333373069763,
      0.800000011920929,
      0.8083333373069763,
      0.8083333373069763,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.800000011920929,
      0.8083333373069763,
      0.8083333373069763,
      0.8083333373069763,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.8083333373069763,
      0.824999988079071,
      0.8166666626930237,
      0.8166666626930237,
      0.8166666626930237,
      0.824999988079071,
      0.8333333134651184,
      0.824999988079071,
      0.824999988079071,
      0.8333333134651184,
      0.8333333134651184,
      0.8416666388511658,
      0.8416666388511658,
      0.8416666388511658,
      0.8416666388511658,
      0.8583333492279053,
      0.8666666746139526,
      0.8500000238418579,
      0.8583333492279053,
      0.8583333492279053]}



Now visualize the loss over time using `history.history`: 


```python
# The history.history["loss"] entry is a dictionary with as many values as epochs that the
# model was trained on. 
epochs = len(history.history["loss"])  
xticks = list(range(0, epochs, 10))
# The xticklabels are modified for the sake of understanding because the first 
# epoch is called Epoch 1, not Epoch 0.
xticklabels = [xtick for xtick in xticks]
print("xticks:")
print(xticks)
print("xticklabels:")
print(xticklabels)

fig, ax = plt.subplots(figsize=(10, 7))
ax.plot(history.history["accuracy"], marker='^')
ax.plot(history.history["val_accuracy"], marker='s')
plt.title("Model Accuracy")
plt.ylabel("Accuracy")
plt.xlabel("Epoch")
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)
plt.legend(["train", "validation"], loc="lower right")
plt.show()
```

    xticks:
    [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]
    xticklabels:
    [0, 10, 20, 30, 40, 50, 60, 70, 80, 90]



![png](output_41_1.png)



```python
fig, ax = plt.subplots(figsize=(10, 7))
ax.plot(history.history["loss"], marker='^')
ax.plot(history.history["val_loss"], marker='s')
plt.title("Model loss")
plt.ylabel("Loss")
plt.xlabel("Epoch")
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)
plt.legend(["train", "validation"], loc="upper right")
plt.show()
```


![png](output_42_0.png)


**Congratulations**! You've finished the assignment and built two models: One that recognizes  smiles, and another that recognizes SIGN language with almost 80% accuracy on the test set. In addition to that, you now also understand the applications of two Keras APIs: Sequential and Functional. Nicely done! 

By now, you know a bit about how the Functional API works and may have glimpsed the possibilities. In your next assignment, you'll really get a feel for its power when you get the opportunity to build a very deep ConvNet, using ResNets! 

<a name='6'></a>
## 6 - Bibliography

You're always encouraged to read the official documentation. To that end, you can find the docs for the Sequential and Functional APIs here: 

https://www.tensorflow.org/guide/keras/sequential_model

https://www.tensorflow.org/guide/keras/functional


```python

```


```python

```


```python

```


```python

```


```python

```
