```python
# ATTENTION: Please do not alter any of the provided code in the exercise. Only add your own code where indicated
# ATTENTION: Please do not add or remove any cells in the exercise. The grader will check specific cells based on the cell position.
# ATTENTION: Please use the provided epoch values when training.

import csv
import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from os import getcwd
```


```python
def get_data(filename):
  # You will need to write code that will read the file passed
  # into this function. The first line contains the column headers
  # so you should ignore it
  # Each successive line contians 785 comma separated values between 0 and 255
  # The first value is the label
  # The rest are the pixel values for that picture
  # The function will return 2 np.array types. One with all the labels
  # One with all the images
  #
  # Tips: 
  # If you read a full line (as 'row') then row[0] has the label
  # and row[1:785] has the 784 pixel values
  # Take a look at np.array_split to turn the 784 pixels into 28x28
  # You are reading in strings, but need the values to be floats
  # Check out np.array().astype for a conversion
    with open(filename) as training_file:
        csv_reader = csv.reader(training_file, delimiter=',')
        first_line = True
        temp_labels= []
        temp_images = []

        for row in csv_reader:
        # Makes first iteration of loop for first row do nothing.
        # That's how you skip the first row with headers.
            if first_line: 
                first_line = False
            else:
                temp_labels.append(row[0])
                image_data = row[1:785]
                image_array = np.array_split(image_data, 28) # Make 28 x 28
                temp_images.append(image_array)
        
        images = np.array(temp_images).astype('float')
        labels = np.array(temp_labels).astype('float')
    return images, labels

path_sign_mnist_train = f"{getcwd()}/../tmp2/sign_mnist_train.csv"
path_sign_mnist_test = f"{getcwd()}/../tmp2/sign_mnist_test.csv"
training_images, training_labels = get_data(path_sign_mnist_train)
testing_images, testing_labels = get_data(path_sign_mnist_test)

# Keep these
print(training_images.shape)
print(training_labels.shape)
print(testing_images.shape)
print(testing_labels.shape)

# Their output should be:
# (27455, 28, 28)
# (27455,)
# (7172, 28, 28)
# (7172,)
```

    (27455, 28, 28)
    (27455,)
    (7172, 28, 28)
    (7172,)



```python
# In this section you will have to add another dimension to the data
# So, for example, if your array is (10000, 28, 28)
# You will need to make it (10000, 28, 28, 1)
# Hint: np.expand_dims

training_images = np.expand_dims(training_images, axis=3)
testing_images = np.expand_dims(testing_images, axis=3)

# Create an ImageDataGenerator and do Image Augmentation
train_datagen = ImageDataGenerator(
    rescale=1./255,
    rotation_range=40,
    width_shift_range=0.2,
    height_shift_range=0.2,
    shear_range=0.2,
    zoom_range=0.2,
    fill_mode='nearest',
    horizontal_flip=True
)

validation_datagen = ImageDataGenerator(
    rescale=1./255)
    
# Keep These
print(training_images.shape)
print(testing_images.shape)
    
# Their output should be:
# (27455, 28, 28, 1)
# (7172, 28, 28, 1)
```

    (27455, 28, 28, 1)
    (7172, 28, 28, 1)



```python
# Define the model
model = tf.keras.models.Sequential([
    # Your Code Here
    tf.keras.layers.Conv2D(64,(3,3),activation='relu',input_shape=(28,28,1)),
    tf.keras.layers.MaxPooling2D(2,2),
    
    tf.keras.layers.Conv2D(64,(3,3),activation='relu'),
    tf.keras.layers.MaxPooling2D(2,2),
    
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dropout(0.5),
    tf.keras.layers.Dense(512,activation='relu'),
    tf.keras.layers.Dense(26,activation='softmax')
])

train_generator=train_datagen.flow(
    training_images,
    training_labels,
    batch_size=32

)
validation_generator=validation_datagen.flow(
    testing_images,
    testing_labels,
    batch_size=32
)

class mycallback(tf.keras.callbacks.Callback):
    def on_epoch_end(self,epoch,logs={}):
        if(logs.get('acc')>0.999):
            print('\n Reached 99.9% accuracy!')
            self.model.stop_training=True
            
callbacks=mycallback()    
# Compile Model. 
model.compile(# Your Code Here
loss='sparse_categorical_crossentropy',
    optimizer='rmsprop',
    metrics=['acc']
)

# Train the Model
history = model.fit_generator(# Your Code Here (set 'epochs' = 2)
    train_generator,
                              steps_per_epoch = len(training_images)/32,
                              epochs = 2,
                              validation_data = validation_generator,
                              validation_steps = len(testing_images)/32,
                              callbacks = [callbacks]
)

model.evaluate(testing_images, testing_labels, verbose=0)
```

    Epoch 1/15
    858/857 [==============================] - 58s 67ms/step - loss: 2.7892 - accuracy: 0.1590 - val_loss: 2.0755 - val_accuracy: 0.3684
    Epoch 2/15
    858/857 [==============================] - 59s 68ms/step - loss: 2.1235 - accuracy: 0.3362 - val_loss: 1.4539 - val_accuracy: 0.5095
    Epoch 3/15
    395/857 [============>.................] - ETA: 28s - loss: 1.7957 - accuracy: 0.4306


    ---------------------------------------------------------------------------

    KeyboardInterrupt                         Traceback (most recent call last)

    <ipython-input-9-548aa908b7a9> in <module>
         20                               epochs=15,
         21                               validation_data=validation_datagen.flow(testing_images, testing_labels, batch_size=32),
    ---> 22                               validation_steps=len(testing_images) / 32)
         23 
         24 model.evaluate(testing_images, testing_labels)


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/engine/training.py in fit_generator(self, generator, steps_per_epoch, epochs, verbose, callbacks, validation_data, validation_steps, validation_freq, class_weight, max_queue_size, workers, use_multiprocessing, shuffle, initial_epoch)
       1295         shuffle=shuffle,
       1296         initial_epoch=initial_epoch,
    -> 1297         steps_name='steps_per_epoch')
       1298 
       1299   def evaluate_generator(self,


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/engine/training_generator.py in model_iteration(model, data, steps_per_epoch, epochs, verbose, callbacks, validation_data, validation_steps, validation_freq, class_weight, max_queue_size, workers, use_multiprocessing, shuffle, initial_epoch, mode, batch_size, steps_name, **kwargs)
        263 
        264       is_deferred = not model._is_compiled
    --> 265       batch_outs = batch_function(*batch_data)
        266       if not isinstance(batch_outs, list):
        267         batch_outs = [batch_outs]


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/engine/training.py in train_on_batch(self, x, y, sample_weight, class_weight, reset_metrics)
        971       outputs = training_v2_utils.train_on_batch(
        972           self, x, y=y, sample_weight=sample_weight,
    --> 973           class_weight=class_weight, reset_metrics=reset_metrics)
        974       outputs = (outputs['total_loss'] + outputs['output_losses'] +
        975                  outputs['metrics'])


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/engine/training_v2_utils.py in train_on_batch(model, x, y, sample_weight, class_weight, reset_metrics)
        262       y,
        263       sample_weights=sample_weights,
    --> 264       output_loss_metrics=model._output_loss_metrics)
        265 
        266   if reset_metrics:


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/engine/training_eager.py in train_on_batch(model, inputs, targets, sample_weights, output_loss_metrics)
        309           sample_weights=sample_weights,
        310           training=True,
    --> 311           output_loss_metrics=output_loss_metrics))
        312   if not isinstance(outs, list):
        313     outs = [outs]


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/engine/training_eager.py in _process_single_batch(model, inputs, targets, output_loss_metrics, sample_weights, training)
        270                         loss_scale_optimizer.LossScaleOptimizer):
        271             grads = model.optimizer.get_unscaled_gradients(grads)
    --> 272           model.optimizer.apply_gradients(zip(grads, trainable_weights))
        273       else:
        274         logging.warning('The list of trainable weights is empty. Make sure that'


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/optimizer_v2/optimizer_v2.py in apply_gradients(self, grads_and_vars, name)
        439           functools.partial(self._distributed_apply, apply_state=apply_state),
        440           args=(grads_and_vars,),
    --> 441           kwargs={"name": name})
        442 
        443   def _distributed_apply(self, distribution, grads_and_vars, name, apply_state):


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/distribute/distribute_lib.py in merge_call(self, merge_fn, args, kwargs)
       1915     if kwargs is None:
       1916       kwargs = {}
    -> 1917     return self._merge_call(merge_fn, args, kwargs)
       1918 
       1919   def _merge_call(self, merge_fn, args, kwargs):


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/distribute/distribute_lib.py in _merge_call(self, merge_fn, args, kwargs)
       1922         distribution_strategy_context._CrossReplicaThreadMode(self._strategy))  # pylint: disable=protected-access
       1923     try:
    -> 1924       return merge_fn(self._strategy, *args, **kwargs)
       1925     finally:
       1926       _pop_per_thread_mode()


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/keras/optimizer_v2/optimizer_v2.py in _distributed_apply(self, distribution, grads_and_vars, name, apply_state)
        480         # delays. See b/136304694.
        481         with backend.name_scope(
    --> 482             scope_name), distribution.extended.colocate_vars_with(var):
        483           update_ops.extend(
        484               distribution.extended.update(


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/distribute/distribute_lib.py in colocate_vars_with(self, colocate_with_variable)
       2087   def colocate_vars_with(self, colocate_with_variable):
       2088     """Does not require `self.scope`."""
    -> 2089     _require_strategy_scope_extended(self)
       2090     return ops.colocate_with(colocate_with_variable)
       2091 


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/distribute/distribute_lib.py in _require_strategy_scope_extended(extended)
        245 def _require_strategy_scope_extended(extended):
        246   """Verify in a `distribution_strategy.scope()` in this thread."""
    --> 247   context = _get_per_thread_mode()
        248   if context.strategy.extended is extended: return
        249   # Report error.


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/distribute/distribution_strategy_context.py in _get_per_thread_mode()
         78 def _get_per_thread_mode():
         79   try:
    ---> 80     return ops.get_default_graph()._distribution_strategy_stack[-1]  # pylint: disable=protected-access
         81   except (AttributeError, IndexError):
         82     return _get_default_replica_mode()


    /usr/local/lib/python3.6/dist-packages/tensorflow_core/python/framework/ops.py in _distribution_strategy_stack(self)
       5027   def _distribution_strategy_stack(self):
       5028     """A stack to maintain distribution strategy context for each thread."""
    -> 5029     if not hasattr(self._thread_local, "_distribution_strategy_stack"):
       5030       self._thread_local._distribution_strategy_stack = []  # pylint: disable=protected-access
       5031     return self._thread_local._distribution_strategy_stack  # pylint: disable=protected-access


    KeyboardInterrupt: 



```python
# Plot the chart for accuracy and loss on both training and validation
%matplotlib inline
import matplotlib.pyplot as plt
acc = history.history['acc']
val_acc = history.history['val_acc']
loss = history.history['loss']
val_loss = history.history['val_loss']

epochs = range(len(acc))

plt.plot(epochs, acc, 'r', label='Training accuracy')
plt.plot(epochs, val_acc, 'b', label='Validation accuracy')
plt.title('Training and validation accuracy')
plt.legend()
plt.figure()

plt.plot(epochs, loss, 'r', label='Training Loss')
plt.plot(epochs, val_loss, 'b', label='Validation Loss')
plt.title('Training and validation loss')
plt.legend()

plt.show()
```


![png](output_4_0.png)



![png](output_4_1.png)


# Submission Instructions


```python
# Now click the 'Submit Assignment' button above.
```

# When you're done or would like to take a break, please run the two cells below to save your work and close the Notebook. This will free up resources for your fellow learners. 


```javascript
%%javascript
<!-- Save the notebook -->
IPython.notebook.save_checkpoint();
```


```javascript
%%javascript
IPython.notebook.session.delete();
window.onbeforeunload = null
setTimeout(function() { window.close(); }, 1000);
```
