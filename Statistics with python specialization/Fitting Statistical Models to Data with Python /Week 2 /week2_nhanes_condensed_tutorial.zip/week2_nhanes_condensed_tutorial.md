
# Linear Regression with NHANES Data

This tutorial will be taking an excerpt from the NHANES case study provided in this week and reviewing the linear regression portion.  We will cover model parameters such as coefficients, r-squared, and correlation.  Additionally, we will construct models utilzing more than one predictor, introduce how categorical variables are handled, and generate visualizations of our models.

As with our previous work, we will be using the
[Pandas](http://pandas.pydata.org) library for data management, the
[Numpy](http://www.numpy.org) library for numerical calculations, and
the [Statsmodels](http://www.statsmodels.org) library for statistical
modeling.

We begin by importing the libraries that we will be using:


```python
%matplotlib inline
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import statsmodels.api as sm
import numpy as np
```


```python
url = "nhanes_2015_2016.csv"
da = pd.read_csv(url)
```


```python
# Drop unused columns, drop rows with any missing values.
vars = ["BPXSY1", "RIDAGEYR", "RIAGENDR", "RIDRETH1", "DMDEDUC2", "BMXBMI", "SMQ020"]
da = da[vars].dropna()
```


```python
da.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>BPXSY1</th>
      <th>RIDAGEYR</th>
      <th>RIAGENDR</th>
      <th>RIDRETH1</th>
      <th>DMDEDUC2</th>
      <th>BMXBMI</th>
      <th>SMQ020</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>128.0</td>
      <td>62</td>
      <td>1</td>
      <td>3</td>
      <td>5.0</td>
      <td>27.8</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>146.0</td>
      <td>53</td>
      <td>1</td>
      <td>3</td>
      <td>3.0</td>
      <td>30.8</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>138.0</td>
      <td>78</td>
      <td>1</td>
      <td>3</td>
      <td>3.0</td>
      <td>28.8</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>132.0</td>
      <td>56</td>
      <td>2</td>
      <td>3</td>
      <td>5.0</td>
      <td>42.4</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>100.0</td>
      <td>42</td>
      <td>2</td>
      <td>4</td>
      <td>4.0</td>
      <td>20.3</td>
      <td>2</td>
    </tr>
  </tbody>
</table>
</div>



## Linear regression


### Simple Linear Regression with One Covariate


```python
### OLS Model of BPXSY1 with RIDAGEYR
model = sm.OLS.from_formula("BPXSY1 ~ RIDAGEYR", data=da)
result = model.fit()
result.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>BPXSY1</td>      <th>  R-squared:         </th> <td>   0.207</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.207</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   1333.</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Wed, 14 Apr 2021</td> <th>  Prob (F-statistic):</th> <td>2.09e-259</td>
</tr>
<tr>
  <th>Time:</th>                 <td>09:23:55</td>     <th>  Log-Likelihood:    </th> <td> -21530.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  5102</td>      <th>  AIC:               </th> <td>4.306e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  5100</td>      <th>  BIC:               </th> <td>4.308e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     1</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
      <td></td>         <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th> <td>  102.0935</td> <td>    0.685</td> <td>  149.120</td> <td> 0.000</td> <td>  100.751</td> <td>  103.436</td>
</tr>
<tr>
  <th>RIDAGEYR</th>  <td>    0.4759</td> <td>    0.013</td> <td>   36.504</td> <td> 0.000</td> <td>    0.450</td> <td>    0.501</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>690.261</td> <th>  Durbin-Watson:     </th> <td>   2.039</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>1505.999</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 0.810</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 5.112</td>  <th>  Cond. No.          </th> <td>    156.</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.




```python
da.BPXSY1.std()
```




    18.486559500782416



### R-squared and correlation

The primary summary statistic for assessing the strength of a
predictive relationship in a regression model is the *R-squared*, which is
shown to be 0.207 in the regression output above.  This means that 21%
of the variation in SBP is explained by age.  Note that this value is
exactly the same as the squared Pearson correlation coefficient
between SBP and age, as shown below.


```python
cc = da[["BPXSY1", "RIDAGEYR"]].corr()
print(cc.BPXSY1.RIDAGEYR**2)
```

    0.20715459625188243


### Adding a Second Predictor

Now we will add gender to our initial model so we have two predictors, age and gender.


```python
# Create a labeled version of the gender variable
da["RIAGENDRx"] = da.RIAGENDR.replace({1: "Male", 2: "Female"})
```


```python
model = sm.OLS.from_formula("BPXSY1 ~ RIDAGEYR + RIAGENDRx", data=da)
result = model.fit()
result.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>BPXSY1</td>      <th>  R-squared:         </th> <td>   0.215</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.214</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   697.4</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Wed, 14 Apr 2021</td> <th>  Prob (F-statistic):</th> <td>1.87e-268</td>
</tr>
<tr>
  <th>Time:</th>                 <td>09:23:56</td>     <th>  Log-Likelihood:    </th> <td> -21505.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  5102</td>      <th>  AIC:               </th> <td>4.302e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  5099</td>      <th>  BIC:               </th> <td>4.304e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     2</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
          <td></td>             <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>         <td>  100.6305</td> <td>    0.712</td> <td>  141.257</td> <td> 0.000</td> <td>   99.234</td> <td>  102.027</td>
</tr>
<tr>
  <th>RIAGENDRx[T.Male]</th> <td>    3.2322</td> <td>    0.459</td> <td>    7.040</td> <td> 0.000</td> <td>    2.332</td> <td>    4.132</td>
</tr>
<tr>
  <th>RIDAGEYR</th>          <td>    0.4739</td> <td>    0.013</td> <td>   36.518</td> <td> 0.000</td> <td>    0.448</td> <td>    0.499</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>706.732</td> <th>  Durbin-Watson:     </th> <td>   2.036</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>1582.730</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 0.818</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 5.184</td>  <th>  Cond. No.          </th> <td>    168.</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



The syntax `RIDAGEYR + RIAGENDRx` in the cell above does not mean
that these two variables are literally added together.  Instead,
it means that these variables are both included in the model as
predictors of blood pressure (`BPXSY1`).

The model that was fit above uses both age and gender to explain the
variation in SBP.  It finds that two people with the same gender whose
ages differ by one year tend to have blood pressure values differing
by 0.47 units, which is essentially the same gender parameter that we found above in
the model based on age alone.  This model also shows us that comparing
a man and a woman of the same age, the man will on average have 3.23 units
greater SBP.

It is very important to emphasize that the age coefficient of 0.47 is
only meaningful when comparing two people of the same gender, and the
gender coefficient of 3.23 is only meaningful when comparing two
people of the same age.
Moreover, these effects are additive, meaning that if we compare, say, a 50 year
old man to a 40 year old woman, the man's blood pressure will on
average be around 3.23 + 10*0.47 = 7.93 units higher, with the first
term in this sum being attributable to gender, and the second term
being attributable to age.

We noted above that the regression coefficient for age did not change
by much when we added gender to the model.  It is important to note
however that in general, the estimated coefficient of a variable in a
regression model will change when other variables are added or
removed.  We see here that a coefficient is nearly unchanged if any
variables that are added to or removed from the model are
approximately uncorrelated with the other covariates that are already
in the model.

Below we confirm that gender and age are nearly uncorrelated in this
data set (the correlation of around -0.02 is negligible):


```python
# We need to use the original, numerical version of the gender
# variable to calculate the correlation coefficient.
da[["RIDAGEYR", "RIAGENDR"]].corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RIDAGEYR</th>
      <th>RIAGENDR</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>RIDAGEYR</th>
      <td>1.000000</td>
      <td>-0.021398</td>
    </tr>
    <tr>
      <th>RIAGENDR</th>
      <td>-0.021398</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



### A model with three variables

Next we add a third variable, body mass index (BMI), to the model predicting SBP.
[BMI](https://en.wikipedia.org/wiki/Body_mass_index) is a measure that is used
to assess if a person has healthy weight given their height.
[BMXBMI](https://wwwn.cdc.gov/Nchs/Nhanes/2015-2016/BMX_I.htm#BMXBMI)
is the NHANES variable containing the BMI value for each subject.


```python
model = sm.OLS.from_formula("BPXSY1 ~ RIDAGEYR + BMXBMI + RIAGENDRx", data=da)
result = model.fit()
result.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>BPXSY1</td>      <th>  R-squared:         </th> <td>   0.228</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.228</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   502.0</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Wed, 14 Apr 2021</td> <th>  Prob (F-statistic):</th> <td>8.54e-286</td>
</tr>
<tr>
  <th>Time:</th>                 <td>09:23:57</td>     <th>  Log-Likelihood:    </th> <td> -21461.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  5102</td>      <th>  AIC:               </th> <td>4.293e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>  5098</td>      <th>  BIC:               </th> <td>4.296e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>     3</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
          <td></td>             <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>Intercept</th>         <td>   91.5840</td> <td>    1.198</td> <td>   76.456</td> <td> 0.000</td> <td>   89.236</td> <td>   93.932</td>
</tr>
<tr>
  <th>RIAGENDRx[T.Male]</th> <td>    3.5783</td> <td>    0.457</td> <td>    7.833</td> <td> 0.000</td> <td>    2.683</td> <td>    4.474</td>
</tr>
<tr>
  <th>RIDAGEYR</th>          <td>    0.4709</td> <td>    0.013</td> <td>   36.582</td> <td> 0.000</td> <td>    0.446</td> <td>    0.496</td>
</tr>
<tr>
  <th>BMXBMI</th>            <td>    0.3060</td> <td>    0.033</td> <td>    9.351</td> <td> 0.000</td> <td>    0.242</td> <td>    0.370</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>752.325</td> <th>  Durbin-Watson:     </th> <td>   2.040</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>1776.087</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 0.847</td>  <th>  Prob(JB):          </th> <td>    0.00</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 5.343</td>  <th>  Cond. No.          </th> <td>    316.</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.



Not surprisingly, BMI is positively associated with SBP.  Given two
subjects with the same gender and age, and whose BMI differs by 1
unit, the person with greater BMI will have, on average, 0.31 units
greater systolic blood pressure (SBP).  Also note that after adding
BMI to the model, the coefficient for gender became somewhat greater.
This is due to the fact that the three covariates in the model, age,
gender, and BMI, are mutually correlated, as shown next:


```python
da[["RIDAGEYR", "RIAGENDR", "BMXBMI"]].corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>RIDAGEYR</th>
      <th>RIAGENDR</th>
      <th>BMXBMI</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>RIDAGEYR</th>
      <td>1.000000</td>
      <td>-0.021398</td>
      <td>0.023089</td>
    </tr>
    <tr>
      <th>RIAGENDR</th>
      <td>-0.021398</td>
      <td>1.000000</td>
      <td>0.080463</td>
    </tr>
    <tr>
      <th>BMXBMI</th>
      <td>0.023089</td>
      <td>0.080463</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



Although the correlations among these three variables are not strong,
they are sufficient to induce fairly substantial differences in the
regression coefficients (e.g. the gender coefficient changes from 3.23
to 3.58).  In this example, the gender effect becomes larger after we
control for BMI - we can take this to mean that BMI was masking part
of the association between gender and blood pressure.  In other settings, including
additional covariates can reduce the association between a covariate
and an outcome.

### Visualization of the Fitted Models

In this section we demonstrate some graphing techniques that can be
used to gain a better understanding of a regression model that has
been fit to data.


```python
from statsmodels.sandbox.predict_functional import predict_functional

# Fix certain variables at reference values.  Not all of these
# variables are used here, but we provide them with a value anyway
# to prevent a warning message from appearing.
values = {"RIAGENDRx": "Female", "RIAGENDR": 1, "BMXBMI": 25,
          "DMDEDUC2": 1, "RIDRETH1": 1, "SMQ020": 1}

pr, cb, fv = predict_functional(result, "RIDAGEYR",
                values=values, ci_method="simultaneous")

ax = sns.lineplot(fv, pr, lw=4)
ax.fill_between(fv, cb[:, 0], cb[:, 1], color='grey', alpha=0.4)
ax.set_xlabel("Age")
_ = ax.set_ylabel("SBP")
```


![png](output_20_0.png)


The analogous plot for BMI is shown next.  Here we fix the
gender as "female" and the age at 50, so we are looking
at the relationship between expected SBP and age for women
of age 50.


```python
del values["BMXBMI"]
values["RIDAGEYR"] = 50
pr, cb, fv = predict_functional(result, "BMXBMI",
                values=values, ci_method="simultaneous")

ax = sns.lineplot(fv, pr, lw=4)
ax.fill_between(fv, cb[:, 0], cb[:, 1], color='grey', alpha=0.4)
ax.set_xlabel("BMI")
_ = ax.set_ylabel("SBP")
```


![png](output_22_0.png)


Below we show the plot of residuals on fitted values for the NHANES
data.  It appears that we have a modestly increasing mean/variance
relationship.  That is, the scatter around the mean blood pressure is
greater when the mean blood pressure itself is greater.


```python
pp = sns.scatterplot(result.fittedvalues, result.resid)
pp.set_xlabel("Fitted values")
_ = pp.set_ylabel("Residuals")
```


![png](output_24_0.png)


A "component plus residual plot" or "partial residual plot" is
intended to show how the data would look if all but one covariate
could be fixed at reference values.  By controlling the values of
these covariates, all remaining variation is due either to the "focus
variable" (the one variable that is left unfixed, and is plotted on
the horizontal axis), or to sources of variation that are unexplained
by any of our covariates.

For example, the partial residual plot below shows how age (horizontal
axis) and SBP (vertical axis) would be related if gender and BMI were
fixed.  Note that the origin of the vertical axis in these plots is
not meaningful (we are not implying that anyone's blood pressure would
be negative), but the differences along the vertical axis are
meaningful.  This plot implies that when BMI and gender are held
fixed, the average blood pressures of an 80 and 18 year old differ by
around 30 mm/Hg.  This plot also shows, as discussed above,
that the deviations from the
mean are somewhat smaller at the low end of the range compared to the
high end of the range.  We also see that at the high end of the range, the
deviations from the mean are somewhat right-skewed, with
exceptionally high SBP values being more common than exceptionally low SBP values.


```python
from statsmodels.graphics.regressionplots import plot_ccpr

ax = plt.axes()
plot_ccpr(result, "RIDAGEYR", ax)
_ = ax.lines[0].set_alpha(0.2) # Reduce overplotting with transparency
```


![png](output_26_0.png)


Next we have a partial residual plot that shows how BMI (horizontal
axis) and SBP (vertical axis) would be related if gender and age were
fixed.  Compared to the plot above, we see here that age is more
uniformly distributed than BMI.  Also, it appears that there is more
scatter in the partial residuals for BMI compared to what we saw above
for age. Thus there seems to be less information about SBP in BMI,
although a trend certainly exists.


```python
ax = plt.axes()
plot_ccpr(result, "BMXBMI", ax)
_ = ax.lines[0].set_alpha(0.2)
```


![png](output_28_0.png)

